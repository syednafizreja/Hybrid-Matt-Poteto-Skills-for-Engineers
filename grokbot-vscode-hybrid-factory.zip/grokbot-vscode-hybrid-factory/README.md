# Hybrid AI Engineering System (Matt Pocock + Lauren Tan) for Grok Bot in VS Code

A single, cohesive, zero-bloat **Hybrid AI Engineering System** engineered specifically for **Grok Bot / Grok Build running inside VS Code**, portable to any GitHub repository you create so you never lose your workflow, skills, or guardrails.

---

## Why This Hybrid Is Faster & Smarter Than Installing Both Packs Raw

Installing all 27 skills from `mattpocock/skills` plus all 45+ skills from `pstack` side-by-side causes **context bloat** (every model-invoked skill description loads on every turn) and **tool conflicts** (duplicate `code-review`, `diagnosing-bugs`, and Cursor-only frontmatter).

This hybrid merges the strongest non-overlapping mechanisms from both systems into **one unified 6-stage loop** and **12 unified `.grok/skills/`**:

| Stage | Unified Slash Command | Merged From | What It Does in VS Code |
| :--- | :--- | :--- | :--- |
| **0. Bootstrap** | `/hybrid-init` | Matt `setup-matt-pocock-skills` + Lauren `setup-pstack` + `create-verification-skill` | Detects your stack, creates `GLOSSARY.md`, `FEATURE_MAP.md`, `docs/adr/`, `model-routing.md`, and `.grok/skills/verify-app/SKILL.md` in one pass. |
| **1. Investigate** | `/hybrid-investigate` | Lauren `/how` + `/why` + `diagnosing-bugs` | Forces the agent to read real code, Git blame/ADRs, and live runtime traces **before** hypothesizing. Checks if bugs are already fixed on `main`. |
| **2. Align & Shape** | `/hybrid-grill` | Matt `grill-with-docs` + `domain-modeling` + `wayfinder` + Lauren `/interrogate` | Interviews you to close communication gaps, updates `GLOSSARY.md` & `docs/adr/` inline, and runs a multi-model devil's-advocate check on big decisions. |
| **3. Spec & Slice** | `/hybrid-plan` | Matt `to-spec` + `to-tickets` (`<150k` smart zone) + Lauren `sequence-verifiable-units` | Converts agreed conversations into a GitHub Spec + vertical tracer-bullet sub-issues, each sized to `<150k` tokens and one atomic revertible PR. |
| **4. Build & Verify** | `/hybrid-build` | Matt `implement-spec` + `tdd` + Lauren `poteto-mode` + `verify-app` | Dispatches fresh sub-agents in isolated Git worktrees, drives TDD at seams, proves behavior against the **real running app**, and strips slop (`unslop`). |
| **5. Review & Ship** | `/hybrid-ship` | Matt `code-review` + `pr` (Merge Danger) + Lauren 4-Axis Review + `comment-sicko` | Runs 4-axis adversarial review (Spec + Architecture + Runtime Proof + Security), checks Layer-2 CI boundaries, and opens a PR with Merge Danger classification. |
| **6. Ratchet & Eval** | `/hybrid-retro` | Matt `retro` + `improve-codebase-architecture` + Lauren Blind Skill Eval | Turns recurring review comments into **hard Layer-2 CI rules** (`scripts/check-boundaries.mjs`), refactors hotspots into deep modules, and tests skill edits blind. |

---

## Directory Structure (Save This as Your Personal Template Repo!)

```text
grokbot-vscode-hybrid-factory/
├── README.md                                   # This guide
├── install.sh                                  # One-command installer for any repo + VS Code settings
├── verify-setup.sh                             # Audits your repo, VS Code config, skills, and Layer-2 CI
├── .vscode/
│   ├── settings.json                           # VS Code terminal, worktree, and agent workspace defaults
│   └── tasks.json                              # One-click VS Code tasks (Verify, Boundary Guard, Stale Worktree Metadata)
├── .grok/
│   └── skills/                                 # 12 unified, lean, VS-Code-native skills (zero bloat)
│       ├── hybrid-init/SKILL.md
│       ├── hybrid-investigate/SKILL.md
│       ├── hybrid-grill/SKILL.md
│       ├── hybrid-plan/SKILL.md
│       ├── hybrid-build/SKILL.md
│       ├── hybrid-ship/SKILL.md
│       ├── hybrid-retro/SKILL.md
│       ├── verify-app/SKILL.md
│       ├── codebase-design/SKILL.md
│       ├── tdd/SKILL.md
│       ├── unslop/SKILL.md
│       └── handoff/SKILL.md
├── scripts/
│   └── check-boundaries.mjs                    # Zero-dep Layer-2 CI guard (import graph + banned AI slop)
├── docs/
│   ├── adr/
│   │   └── 0000-adr-template.md                # Architectural Decision Record template
│   └── agents/
│       ├── codingstandards.md                  # Deep modules, colocation, strict typing, behavioral tests
│       ├── issue-tracker.md                    # GitHub Issues + Sub-Issues config
│       ├── triage-labels.md                    # Issue & Merge Danger label state machine
│       ├── model-routing.md                    # Per-role Pareto-frontier model & effort sheet
│       └── eval-rubric-template.md             # Blind sub-agent eval & cross-model judge rubric
├── grokbot-cloud/
│   ├── 01-grokbot-private-skills-import.md     # Syncs this hybrid into Grok Bot Private Skills
│   ├── 02-bot-roster-profiles.md               # 5-Bot Roster (@Architect, @Builder, @Benny, @Gardener, @Evaluator)
│   ├── 03-routines.md                          # All 5 cloud automation routines in one clean reference
│   └── 04-trust-ladder.md                      # 4-stage rollout from local VS Code to auto-merge
├── .github/
│   ├── pull_request_template.md                # Enforces Runtime Proof + Feature Map + Merge Danger
│   └── workflows/
│       └── deterministic-ci.yml                # Hard Layer-2 CI (check-boundaries.mjs + Node/Python tests)
├── AGENTS.md                                   # Master operating rules (read automatically by Grok)
├── CLAUDE.md                                   # Pointer to AGENTS.md (cross-tool compatibility)
├── GLOSSARY.md                                 # Ubiquitous domain language dictionary
└── FEATURE_MAP.md                              # Live UI/CLI navigation, shortcuts & selector map
```

---

## Setup in 3 Steps (VS Code + Portable GitHub Repo)

### Step 1: Turn This Folder Into Your Permanent Template Repo
1. Unzip `grokbot-vscode-hybrid-factory.zip`.
2. Open the folder in **VS Code** (`code grokbot-vscode-hybrid-factory`).
3. Create a private or public GitHub repository (e.g., `my-ai-engineering-system`) and push this folder to it—now you never lose your hybrid system, and you can install it into any project anytime.

### Step 2: Install Into Any Project Repo
Inside the VS Code integrated terminal at your target project root, run:

```bash
chmod +x /path/to/grokbot-vscode-hybrid-factory/install.sh
/path/to/grokbot-vscode-hybrid-factory/install.sh .
./verify-setup.sh
```

*(Optional)* If you also want Matt Pocock's and Lauren Tan's raw upstream reference skills alongside this hybrid:
```bash
npx skills@latest add mattpocock/skills -y -g
npx skills@latest add ericlitman/open-pstack -y -g
```

### Step 3: Initialize & Start Coding in VS Code
Open Grok Bot / Grok Build in VS Code and type:
```text
/hybrid-init
```
Then build any feature with the unified loop:
```text
/hybrid-grill   -> align on idea, update GLOSSARY.md & ADRs
/hybrid-plan    -> generate GitHub Spec + <150k tracer-bullet tickets
/hybrid-build   -> parallel Git worktrees + TDD + live verify-app proof + unslop
/hybrid-ship    -> 4-axis adversarial review + Merge Danger PR
/hybrid-retro   -> promote recurring review feedback into Layer-2 CI rules
```
