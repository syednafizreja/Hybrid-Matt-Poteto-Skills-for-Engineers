#!/usr/bin/env bash
set -euo pipefail

# Install the Unified Hybrid AI Engineering System into any target repository.
# Usage: ./install.sh /path/to/target-repo [--force]

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${1:-}"
FORCE="${2:-}"

if [[ -z "${TARGET_DIR}" ]]; then
  echo "Usage: $0 /path/to/target-repo [--force]"
  exit 1
fi

if [[ ! -d "${TARGET_DIR}" ]]; then
  echo "Error: Target directory '${TARGET_DIR}' does not exist."
  exit 1
fi

TARGET_DIR="$(cd "${TARGET_DIR}" && pwd)"

if [[ "${KIT_DIR}" == "${TARGET_DIR}" ]]; then
  echo "Error: Target directory is the template kit itself. Pass the path to a project repo."
  exit 1
fi

copy_item() {
  local src="$1"
  local dst="$2"
  mkdir -p "$(dirname "${dst}")"
  if [[ -f "${dst}" && "${FORCE}" != "--force" ]]; then
    echo "  [skip] ${dst#${TARGET_DIR}/} (already exists; pass --force to overwrite)"
  else
    cp "${src}" "${dst}"
    echo "  [copy] ${dst#${TARGET_DIR}/}"
  fi
}

echo "==> Installing Hybrid AI Engineering System into: ${TARGET_DIR}"

# Root markdown files
for root_file in AGENTS.md CLAUDE.md GLOSSARY.md FEATURE_MAP.md verify-setup.sh; do
  copy_item "${KIT_DIR}/${root_file}" "${TARGET_DIR}/${root_file}"
done
chmod +x "${TARGET_DIR}/verify-setup.sh"

# Directories to sync
for sub in .grok .vscode docs scripts .github grokbot-cloud; do
  while IFS= read -r -d '' file; do
    rel="${file#${KIT_DIR}/}"
    copy_item "${file}" "${TARGET_DIR}/${rel}"
  done < <(find "${KIT_DIR}/${sub}" -type f -print0)
done

chmod +x "${TARGET_DIR}/scripts/check-boundaries.mjs"

# Ensure .gitignore ignores temporary worktrees if .gitignore exists
if [[ -f "${TARGET_DIR}/.gitignore" ]]; then
  if ! grep -q "^\.worktrees/" "${TARGET_DIR}/.gitignore"; then
    printf "
# Isolated agent git worktrees
.worktrees/
" >> "${TARGET_DIR}/.gitignore"
    echo "  [edit] Added .worktrees/ to .gitignore"
  fi
fi

echo ""
echo "Installation complete!"
echo "Next steps inside VS Code:"
echo "  1. Open ${TARGET_DIR} in VS Code"
echo "  2. Run ./verify-setup.sh in the VS Code terminal"
echo "  3. Open Grok Bot / Grok Build and run: /hybrid-init"
